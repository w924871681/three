# Paper3 Final Replication Handoff — Draft for Main to Archive/Publish

COMPLETED;1200/1200 trajectories;240/240 groups;60/60 initial references;2535 original protected files unchanged.

Repository: `D:\dt-talk\DT_LIFECYCLE_ESCALATION`. Results: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3`. Replication digest `7eebe390398395b6ebb1247ba2722b6d5928a65b0c06d039b85eacaa39c359ea`. F1 bundle `ac82f95f4db3b1f624e5348cc8535d75ee3edc8d589c08e74d4aa6fa93f5e228`. Saved statistics receipt: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\statistics_batch20_env_v3\statistics_execution_receipt.json`. All numeric table strings below come from saved, hash-bound CSV cells; no statistic was recalculated by this report generator. **This delivery is valid only with the final COMPLETED DELIVERY_MANIFEST.json binding the exact report SHA.**

## Execution Status

| phase | attempt | start | finish | worker_count | success | failure | source_path | sha256 | external_observation_cutoff | actual_exit | retained_tasks | completed_dynamic_tasks |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| full | A_FULL_0001 | 2026-10-09T09:47:15.977292+00:00 | NOT_VERIFIED | NOT_RECORDED_FOR_FAILURE | False | Original full-phase driver and worker disappeared without a saved terminal record. Exit cause and code are NOT_VERIFIED. | D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\execution\full\A_FULL_0001\failure.json | 18d8c23454f21ddf4823e1c93be502a59659bfeb7e44ab590bc733b00af95cab | 2026-10-09T12:40:37.593642+00:00 | NOT_VERIFIED | 118 | 0 |
| initial | A_INITIAL_0001 | 2026-10-09T09:06:31.259890+00:00 | 2026-10-09T09:25:51.736165+00:00 | 1 | True |  | D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\execution\initial\A_INITIAL_0001\completion.json | 25e55accada7c0df31b8dc522264d44d4aee38c28ecc1f497d9f97ff245031f8 | None | ORIGINAL_TERMINAL_RECEIPT | 0 | 0 |
| minimal | A_MINIMAL_0001 | 2026-10-09T09:29:14.895497+00:00 | 2026-10-09T09:43:10.282571+00:00 | 1 | True |  | D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\execution\minimal\A_MINIMAL_0001\completion.json | a02e0687a94743e9c1cce3da1d3131ba6200e98434f884f2fcf27e6117fae567 | None | ORIGINAL_TERMINAL_RECEIPT | 5 | 0 |
| full | A_FULL_0002 | 2026-10-09T14:14:35.147723+00:00 | 2026-10-09T18:12:23.130066+00:00 | 2 | False | INTENTIONALLY_INTERRUPTED_FOR_AUTHORIZED_DYNAMIC_TAKEOVER | D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\replication_dynamic_takeover_v1\activation001\quiescence\actual_termination_evidence.json | 0fad1092713a712a5a578c8c573f12a3147401455d650ab42692a3b58b4f2744 | None | IDENTITY_PINNED_NATIVE_TERMINATION_OBSERVED | 208 | 0 |
| full | A_DYNAMIC_0001_BRIDGE_SMOKE | 2026-10-09T18:12:43.201139+00:00 | 2026-10-09T18:28:17.696803+00:00 | 1 | True |  | D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\replication_dynamic_takeover_v1\activation001\smoke_coordinator_exit.json | 4663c709480e8c3418118e2747d5fe5ad45291c286340c358bfe1e70ddad9d24 | None | OWNING_POPEN_WAIT_ZERO | 1 | 0 |
| full | A_DYNAMIC_0002 | 2026-10-09T18:28:42.198136+00:00 | 2026-10-10T06:53:53.661825+00:00 | DYNAMIC_0_TO_3 | True |  | D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\replication_dynamic_takeover_v1\activation001\full_coordinator_exit.json | ec5c0b6b2ac65f3c17384014eececb8e361fb8368b90943d76f511ae49b673fd | None | OWNING_POPEN_WAIT_ZERO | 332 | 868 |

## Protocol Integrity

The saved complete gate certifies each of240 center–seed–scenario groups across five methods and all24 stage input fields, initial state, scenario, deployment tier/filter and bank identities. Later deployed-state differences are permitted method consequences. All records use the same preverified F1 batch20 population; no singleton regeneration or old-trajectory reuse. These are executor/statistics gate certifications, plus fresh bound-byte checking here; this report generator does not execute a model or reconstruct initialization.

| file | sha256 |
| --- | --- |
| PAPER3_CANONICAL_INPUT_VERIFICATION_PLAN.md | ee9d379b2d5cd851b370dc657da8f7c431d5c1231f23e1ecccb252358e5acb9c |
| PAPER3_SINGLE_GROUP_INTEGRITY_FORENSIC_REPORT.md | 08cd3143813819a5d8cb4aae35c9a3cfcbe90a418a9f15a89a65e65a97e2d09a |
| artifacts/p3_2_source_bank/p3_mismatch_v2_r3/p3v2_a46_regime_c.pt | cc468e7dc4e27f9a319832c73b3b1e84723c8e8c2a029bee4e8b3e868c40de62 |
| artifacts/p3_2_source_bank/p3_mismatch_v2_r3/p3v2_a57_regime_b.pt | 8cd6f77ea8b54eaf3583bee5619cf2a5a27f9fafff14299bc9165bd83fdd5e09 |
| artifacts/p3_2_source_bank/p3_mismatch_v2_r3/p3v2_a57_regime_c_control.pt | 599394e21dc5bda5721373cae14dfeaa754668ab2e135551a45a77a506df7452 |
| artifacts/p3_2_source_bank/p3_mismatch_v2_r3/source_training_manifest.json | 84ab3d962e9a566303060fa98febcadef26eb1e5d472f81d32d986c35de3b940 |
| artifacts/p3_model_bank_manifest.json | e607a65adfb05b91bf8d9ebac77052d6e13223dfd54e47e655167e20c92342c8 |
| artifacts/p6_recoverability_estimator.pt | 2bbad97427506b0260d3ed9370bc88ed4c91a8879c34787a184e37b5185f6b9b |
| artifacts/p6_recoverability_scaler.json | 1d4cb0b91206bb7defe8389aa8f27ff4776c2acc016662e952bc5f5dc3612f3b |
| artifacts/p7_6b_A1_estimator.pt | e8d047bda5a1e1d62cd9f089db1ade79c0c08750f9dfc878d6e71cc06d8c47cb |
| artifacts/p7_6b_A1_scaler.json | 2c9da0a29b469b8bb92bdbbcb893769a8baa39a57b3dbd26247ba9b1c8564c38 |
| audits/P6_ESTIMATOR_FREEZE.json | 6c5286e3e470413a150b17d908bfd7c87931ce1fa55304ccf270d578fb57374f |
| audits/P7_2_FINAL_CALIBRATION_FREEZE.json | 1973c25adab030d24555e384a8d2f740a193d9debbe0a88c81aac1045da3033f |
| audits/P7_6B_FINAL_SCIENTIFIC_AUDIT.json | 85caccf51c49e7046908a1550df62702c3d16f07d109d9315d6d7a98a102c674 |
| audits/P7_7A2_BRANCH_B_IMPLEMENTATION_QUALIFICATION.json | 31105d81f3ecd41833208a011b38ed2c6fb93acde09d50ddc37b16536fd5f362 |
| audits/P7_7A2_FINAL_HELDOUT_ACCESS_GUARD.json | 024eb629d8da21870c7d647e259b6c3d8e523396113fa63ee69880fa6e4930b5 |
| audits/P7_7_FINAL_HELDOUT_AUTHORIZATION.json | 8f142dccb24a5260f46f4498ac9aa2869db814ceed9c6fafca47f3fbd9fb83da |
| audits/P7_7_FINAL_HELDOUT_SCIENTIFIC_AUDIT.json | c25c01b2b89b43e01d22c157a3bbb39d5321d43fe3cefbeb8dfb9500f175b8dd |
| audits/environment.json | 62032b84e25bd8284352a3db87091c54b8209232092f1fc212f9af782d5de015 |
| configs/P7_6B_FROZEN_PROTOCOL.json | 86272adb9a335ff72030cc4ba5c1fbc5f52e543eacd58ba032433e590251ee23 |
| configs/P7_7A2_INTEGRATION_DECISION.json | 6bd8403c81895f559286b93b6a9eb04fafbebb17b0782be1cbc57fb563f613e1 |
| configs/P7_7_FINAL_LIFECYCLE_PROTOCOL.json | 6339a9247b984b497d1543198b3a7b7c0cfdf9c7bcfd1c52b47b62e17d2fd0df |
| configs/center_splits.json | a3fac8b47e78f5a7de9b4bddb425aca8bff517005751ced09ff1590ea8c5ebe4 |
| configs/p3_mismatch_v2_frozen.json | 529655647c1359e2a164cddc3c5c8b534f5cdbad53e2ede29ada477910975646 |
| configs/p7_2_selected_action_params.json | b400931644cd212e0f8dbb684c516d62618791ee4fc6d1e392ae7a235ecf4cb2 |
| configs/requirements_frozen.txt | aa7f267400111ffcd3a2b4d501557150a8130abe61c83a36ffc6ccdff96a37f4 |
| core/__init__.py | 2eb599b6fa82980c2876a578e58c1bc3e42023720056766f60bcf298416e5a59 |
| core/audits.py | d8bd0a71d1704cd9840bb500a2d56c9d8b79e62225c8586cf1eabb74f09e8654 |
| core/common.py | 10c8dcf936e60e6b9b992778310648e258ed5a105d290d09434ba0c968183aaa |
| core/data.py | 6cd7e375d40c8ecf390fe37dee270d93890b3981f666e521e17441612f304d5e |
| core/models.py | 55028939faab38ea23736d191647f33f08ad48f14f204bbecf55bb3d76642e7e |
| core/oracle.py | 52fd6e3c289a94c615898402cf416132a1e4dd27cb0deb47545ea5f9f5dd2a38 |
| core/p3_2_analysis.py | dc186c0432104c481f6524527631c86e97271926d9a93cf1b0347b4b93a9dba3 |
| core/p3_2_audits.py | 93880b8e7db95416c16d7565cafde41297d316b42ed5d724fda9c2daa21e0d0d |
| core/p3_2_data.py | 0f5a5bff889a0ac866793dc49b21680f927af13c9e6fc3d5c3d75bbf4d9d5b27 |
| core/p3_2_models.py | 05aef843c99e3e4054c6b99a47063e85e6138c50bbb829c39183221a08765982 |
| core/p3_2_oracle.py | 5b67e64ced2cc5ce9f4f9e6873c087ae6216bde15998351de4fa4ac82349f0bf |
| core/p6.py | 7597861c7bddd8e32080a3f83eff0ab0bc0f55db6c6b11aec773794f33cc2b07 |
| core/p7.py | 378f2b8644f97e87fa819661da694d1bfcb163e7d183d110edf5f08c9d6dfe3d |
| core/p7_6b_selected_data.py | dee7eda85297562c96fa23046e2238e10a35ae7a4eaf381173a38d57e3ec59dc |
| core/protocol.py | 8468b32f245e91c9bcbbb95d93b2dea07b75087d951184fb429cc1f7201cc367 |
| docs/P7_7_FINAL_HELDOUT_PARALLEL_RESOURCE_ADJUSTMENT_20261003.md | c76579e557ec825eda4be1d636a245a366589e1d0b000808e34f47293638cbe5 |
| imported/__init__.py | 5ddf6f7296705aadfcbcd3bab925e03addf0c11a71e212511664dba3657ed0cf |
| imported/msa_dti/__init__.py | ac912ef469ceb568a4808e2c9d6a58f35103c7ad58e1d0b0b4d215f19073d435 |
| imported/msa_dti/bank/formal_h1_a1.pt | 0953c393d04cca7bea80b9bc3b4edfaaaeca330785c7e16a1052ad3868cb5988 |
| imported/msa_dti/bank/formal_h1_a46.pt | 34b60214405ed2f5d945eea6a3b2121625819222f36c2dc4ecb229e7409f3f8c |
| imported/msa_dti/bank/formal_h1_a55.pt | ad00ee90288cfcaecd550d42979ae9693fa5fb94350482692755cee521449e1f |
| imported/msa_dti/bank/formal_h1_a56.pt | 2a4d81b8669207180e496c3a09dd7f9e6b8bc6b41016a1927099077a1749d5de |
| imported/msa_dti/bank/formal_h1_a57.pt | 9faaf152f58bb1be4261369914169868b024f4b5baf7ac621b92619ff25682b5 |
| imported/msa_dti/bank/formal_h1_a6.pt | eb574956ef4f59ff82ba316ffd8dfedd580031f8d818243be77d1207608795ef |
| imported/msa_dti/bank/formal_h1_a62.pt | 3bc0540c925c310dbed91dff81d29f9900c109d690fea9a93fc06727cb969b5d |
| imported/msa_dti/bank/medet_style_h1_a57.pt | 304c1eac43f12f99ac1693eaa6a3f29238491562b21a18556a51bb27f475a59a |
| imported/msa_dti/space/__init__.py | 1109e2a58e25136c348845e4b66a8d98bfeceeebb1b23a3c8a57e33431306a86 |
| imported/msa_dti/space/enumerator.py | d7509947a2534e23f37cf9150276eb32886fb975275268ee390c217ab3d793ee |
| imported/msa_dti/space/models.py | a6c73ffac8a0ccad3232f7ea8e75afccc6f0bb7ae5356ba0a02545c67d6e1017 |
| imported/msa_dti/space/profile.py | d7abbbcebe5c4dde274aa193c20bdfc733c07b7efb16b00c00566c4aff154db3 |
| imported/msa_dti/space/types.py | 364016db8428ec5b3004bc290349ffef226feb4a0d776064415ed8f19f7e5e37 |
| imported/ravm_dt/__init__.py | 0114da6465e378037d9c01edffe201729334b4e1cae45e6b174488debf76f5f8 |
| imported/ravm_dt/main_cfg.py | fea128a2649301017a2a8ad6cab3db30392e180c2f3aa1216e9a83fefcd5d005 |
| imported/ravm_dt/sim.py | 930fa8ebe34a442d53af16a054955580f2d0c41ef2514a3cfd125b0e6905883d |
| imported/ravm_dt/statistics.py | e8ef1e2963c60e8b3102d48e19472d902f2666b5c5a5b204a5cd1c6dcbe7a415 |
| reports/P7_7A2_BRANCH_B_INTEGRATION_SPEC.md | cb6953b0c8a00684fcf90be13282a1799a540d7b59fe285a8c584d83e16818e3 |
| reports/P7_7A2_RECOVERABILITY_ESCALATION_INTEGRATION_AUDIT.md | b258990789b2e6cf06fbe48bc10c5a83db1f5134cd5ffb771776a2eb601a9606 |
| reports/P7_7_FINAL_LIFECYCLE_PROTOCOL.md | 3291349cd092257642d01e8edd47fe2691c7228486b3b5b1c935128871cbdc7f |
| results/p7_7/execution_status.json | 9595a844666a4956bd8f2c235809e0f4965805578697bf6e9b24a5eeb13fbd75 |
| scripts/audit_reuse.py | 4bbc76391c0e6ba3021f55c6ef0a42b4a390be449bfc62f650a137f5c2ee8887 |
| scripts/capture_environment.py | 6d85690387c6597c65f49d47e3f93692e3f1092a0e8e619de8072cb55c94d56b |
| scripts/finalize_artifact_manifest.py | 9150bc5c53f5ee3fd5bdbea39b86f37c1b14445bf2f31652f5b9a3c46b59c30f |
| scripts/p7_6a_1_metadata_replay.py | 11fd6c997c5789a0fffba6f4899665c90e8ae184640aa8debcf941d8ad5bb39c |
| scripts/p7_6b_benchmark.py | 9afb6c540ae1551d7b31778cd1852cdf328ceabfb0572ee8bd8cbe830e9b9d7d |
| scripts/p7_6b_compare_qualification.py | d1c49a11e3e325ad82519f3f03c6ef5719f71da51cfc33a9130d6ac313d8a046 |
| scripts/p7_6b_cuda2_benchmark.py | a8f84635ecf04454cdd2c4fa3719e77858d5318a03533b12784e197d673bf313 |
| scripts/p7_6b_fit_r0_testonly.py | 29fa264ac6f037a4179158f86be12a8dcab59eb3911bd8291943b91cedc5810b |
| scripts/p7_6b_fit_supervisor.py | e267030cb42183fdae856fc2a4d44c9bf9a31f02ba02b38c9018e038a8a14497 |
| scripts/p7_6b_full_trajectory_qualification.py | 9314fa8c103806ebaa1d3a9bd0c0f682d2ec22458c6ebb2b1e43ed01a30770f2 |
| scripts/p7_6b_qualification_monitor.py | 0f5f3bdfb104e9e4324fa078e24b010cdf560357ba122ae257c07df7a5178571 |
| scripts/p7_6b_resume_qualification.py | fb62d0783baa567cf961e81624ccdbe73326c3a32923f990100ce21a96198541 |
| scripts/p7_6b_science.py | 302dad26e456105304f3b4d9a5d226f5c149b5b38da8cdcc73abd6c30c0566a5 |
| scripts/paper_figure_style.py | 3a02660a32b1a6a9b011102de8f7d6b5d561882389f502e38a7740f6131d1624 |
| scripts/plot_paper3_figures.py | f3646471d5fd039506a76b6de7e561efc90811f8fab37738052fae2b2632b520 |
| scripts/run_p3.py | c6d269424e057bf591b89b1daad799dd42cbe2da8be6fff30cc680139aa78ba9 |
| scripts/run_p3_2.py | b901feae7b2b3e7d334ba05f5f5c9760ca1f93620d02c945e89c4ec55486d273 |
| scripts/run_p6.py | 9a83e1359426a9a185ec420f539137686c86c4db5afd7a21867520e0f2b71ac0 |
| scripts/run_p7.py | 51dd05f494ae561858c8de804eb34a4ef0590f69480aae0cc5dbae2baff25494 |
| scripts/run_p7_2.py | 91c345761060c15f53fd7338563b185e2f0bdfb33e722678ccb0a41b695da482 |
| scripts/run_p7_3.py | fa8227cf9ae75d753f699823cab77463747794db996656406a3b6ccd718338b7 |
| scripts/run_p7_4b.py | 5f52b379f55b67a667189b3000b311dc0e545c4ccaad603ba46b60133b572d57 |
| scripts/run_p7_4b_cpu_recovery.py | 45f408fc3207787193b1ca356bf1be2380c6c0535b03801c89762d11063fc647 |
| scripts/run_p7_4b_cpu_recovery_supervisor.py | 619d4ad0678108f53a1cddee35669d0c6c745e45953567635ffd7cd0dc14a235 |
| scripts/run_p7_4b_gpu_finalize.py | dd8569634e633a16cd4351ec9f84c028469edd973c087e362fb82041d65e7648 |
| scripts/run_p7_4b_gpu_supervisor.py | 1756b05d7e6227c54448fb2db7e71ce0077d3af22e64f80d6c9a1df3d668d913 |
| scripts/run_p7_6b.py | 8b5bc39f67daee1b2c4227bfa66b1fa6a46bfb1709292c8d950dc3f20b9c3b8f |
| scripts/run_p7_7_final.py | ced000f213f8fc9b52a859e683fc6d27dd04a268641c3d6024500f56c1c158fe |
| scripts/run_p7_seed_bound.py | ef65520df029960077eccf98d72778f0b2ad83858c8dc9098e8d173f6c75b218 |

## Final Scientific Results

| method | mean_lifecycle_service_loss | ci_low | ci_high | n_centers | maintenance_count | maintenance_rate | ri_count | ri_rate | maintenance_cost | ri_cost | total_action_cost | retain_rate | gate_open_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B0 | 0.006604798735543227 | 0.005033902315067533 | 0.008255700132237712 | 20 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 1.0 | 0.0 |
| B1 | 0.0033419799126224664 | 0.0025065074416425488 | 0.004257924875520683 | 20 | 24.0 | 1.0 | 0.0 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0 |
| B2 | 0.004883941472543382 | 0.0038601564234488693 | 0.005979564093428911 | 20 | 6.929166666666667 | 0.2887152777777778 | 0.0 | 0.0 | 0.0016847866106733517 | 0.0 | 0.0016847866106733517 | 0.7112847222222223 | 0.0 |
| B8 | 0.0029126269437559434 | 0.002168176367251312 | 0.003709445781764266 | 20 | 2.975 | 0.12395833333333332 | 0.4375 | 0.018229166666666664 | 0.0007233539627304709 | 0.00106375582754481 | 0.0017871097902752808 | 0.8578125 | 1.0 |
| P7.7 | 0.002940643859084149 | 0.002189337225937733 | 0.0037421774917814014 | 20 | 3.020833333333333 | 0.12586805555555555 | 0.4333333333333333 | 0.018055555555555554 | 0.0007344980713999879 | 0.0010536248196634308 | 0.0017881228910634189 | 0.8560763888888889 | 0.3329861111111111 |

| comparison | mean_difference | ci_low | ci_high | n_centers | bootstrap_resamples | bootstrap_seed | point_estimate_source |
| --- | --- | --- | --- | --- | --- | --- | --- |
| P7.7 - B0 | -0.0036641548764590783 | -0.004573827822422219 | -0.0028134015487948244 | 20 | 4000 | 2904 | OBSERVED_METHOD_CENTER_MEAN_SUBTRACTION |
| P7.7 - B1 | -0.0004013360535383174 | -0.0005435194434220294 | -0.00027324824378676267 | 20 | 4000 | 2904 | OBSERVED_METHOD_CENTER_MEAN_SUBTRACTION |
| P7.7 - B2 | -0.0019432976134592331 | -0.0022800258030189167 | -0.001616486006572207 | 20 | 4000 | 2904 | OBSERVED_METHOD_CENTER_MEAN_SUBTRACTION |
| P7.7 - B8 | 2.8016915328205657e-05 | -1.8594825329880642e-07 | 8.423669423791578e-05 | 20 | 4000 | 2904 | OBSERVED_METHOD_CENTER_MEAN_SUBTRACTION |

| method | scenario | n_centers | lifecycle_service_loss | maintenance_count | maintenance_rate | ri_count | ri_rate | maintenance_cost | ri_cost | total_action_cost | retain_rate | gate_open_rate | ci_low | ci_high | ci_scope |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B0 | C0 | 20 | 0.0029677385190249577 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 1.0 | 0.0 | 0.0021513919983954114 | 0.0038584809885034905 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B0 | C1 | 20 | 0.005501890808530637 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 1.0 | 0.0 | 0.004215176334701532 | 0.006786591578539729 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B0 | C3 | 20 | 0.013005227748302182 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 1.0 | 0.0 | 0.01026285333601057 | 0.01598163196967562 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B0 | C4 | 20 | 0.0049443378663151325 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 1.0 | 0.0 | 0.0032257076614910654 | 0.0067828413889002275 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B1 | C0 | 20 | 0.0024897313197773958 | 24.0 | 1.0 | 0.0 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0 | 0.0017622481989469127 | 0.003293954625832561 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B1 | C1 | 20 | 0.002379289382083193 | 24.0 | 1.0 | 0.0 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0 | 0.0017222808864794889 | 0.0030959003040076523 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B1 | C3 | 20 | 0.0053288546640235124 | 24.0 | 1.0 | 0.0 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0 | 0.004273504935896299 | 0.006441385599122846 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B1 | C4 | 20 | 0.003170044284605764 | 24.0 | 1.0 | 0.0 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0058354605396743866 | 0.0 | 0.0 | 0.002166302112353959 | 0.004248527320354091 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B2 | C0 | 20 | 0.002903606050676899 | 2.6333333333333333 | 0.10972222222222221 | 0.0 | 0.0 | 0.0006402796981031619 | 0.0 | 0.0006402796981031619 | 0.8902777777777778 | 0.0 | 0.002113984402379477 | 0.0037639928280795067 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B2 | C1 | 20 | 0.002935378827351087 | 6.716666666666667 | 0.2798611111111111 | 0.0 | 0.0 | 0.0016331184704783178 | 0.0 | 0.0016331184704783178 | 0.7201388888888889 | 0.0 | 0.0021942931643560665 | 0.0037357532797876857 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B2 | C3 | 20 | 0.009563389771069018 | 9.5 | 0.39583333333333337 | 0.0 | 0.0 | 0.002309869796954445 | 0.0 | 0.002309869796954445 | 0.6041666666666666 | 0.0 | 0.008105362926728756 | 0.011097428126266904 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B2 | C4 | 20 | 0.004133391241076525 | 8.866666666666667 | 0.36944444444444446 | 0.0 | 0.0 | 0.002155878477157482 | 0.0 | 0.002155878477157482 | 0.6305555555555555 | 0.0 | 0.0028176107592344127 | 0.005539689181677103 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B8 | C0 | 20 | 0.0028481570255987918 | 1.45 | 0.06041666666666666 | 0.0 | 0.0 | 0.00035255907427199416 | 0.0 | 0.00035255907427199416 | 0.9395833333333334 | 1.0 | 0.0020802448624342813 | 0.003680249938732029 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B8 | C1 | 20 | 0.002676047857352791 | 5.25 | 0.21875 | 0.016666666666666666 | 0.0006944444444444444 | 0.001276506993053772 | 4.052403152551657e-05 | 0.0013170310245792887 | 0.7805555555555556 | 1.0 | 0.002004112571375016 | 0.0034070302386226105 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B8 | C3 | 20 | 0.0033109508967754664 | 3.3666666666666663 | 0.14027777777777778 | 1.05 | 0.04375 | 0.0008185854368154349 | 0.002553013986107544 | 0.0033715994229229786 | 0.8159722222222221 | 1.0 | 0.002434113906413889 | 0.004215649491104867 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| B8 | C4 | 20 | 0.0028153519952967246 | 1.8333333333333333 | 0.07638888888888888 | 0.6833333333333333 | 0.02847222222222222 | 0.00044576434678068237 | 0.0016614852925461794 | 0.0021072496393268617 | 0.8951388888888889 | 1.0 | 0.002097232582190271 | 0.0036001398796684553 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| P7.7 | C0 | 20 | 0.0028481570255987918 | 1.45 | 0.06041666666666666 | 0.0 | 0.0 | 0.00035255907427199416 | 0.0 | 0.00035255907427199416 | 0.9395833333333334 | 0.40902777777777777 | 0.0020802448624342813 | 0.003680249938732029 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| P7.7 | C1 | 20 | 0.0026689542417039367 | 5.266666666666667 | 0.21944444444444447 | 0.0 | 0.0 | 0.0012805593962063237 | 0.0 | 0.0012805593962063237 | 0.7805555555555556 | 0.2743055555555556 | 0.001998312560903691 | 0.003399904709492855 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| P7.7 | C3 | 20 | 0.0034232664890926877 | 3.5333333333333337 | 0.14722222222222223 | 1.05 | 0.04375 | 0.0008591094683409514 | 0.002553013986107544 | 0.003412123454448495 | 0.8090277777777779 | 0.3375 | 0.0025182235328540833 | 0.004372535389833907 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |
| P7.7 | C4 | 20 | 0.0028221976799411804 | 1.8333333333333333 | 0.07638888888888888 | 0.6833333333333333 | 0.02847222222222222 | 0.00044576434678068237 | 0.0016614852925461794 | 0.0021072496393268617 | 0.8951388888888889 | 0.3111111111111111 | 0.002103208055476797 | 0.003604612616915499 | ADDITIONAL_CENTER_LEVEL_DESCRIPTIVE_STRATUM_INTERVAL |

| metric | count | rate | denominator |
| --- | --- | --- | --- |
| correct retain | 407 | 0.07065972222222222 | 5760 |
| unnecessary RI | 12 | 0.0020833333333333333 | 5760 |
| correct escalation | 92 | 0.01597222222222222 | 5760 |
| missed escalation | 2100 | 0.3645833333333333 | 5760 |

| method | n_centers | n_trajectories | n_stage_records | feasible_candidate_count_total_recorded | feasible_candidate_count_mean_trajectory_center_averaged | ri_search_updates_charged_total_recorded | ri_search_updates_charged_mean_trajectory_center_averaged | source_cache_hits_total_recorded | source_cache_hits_mean_trajectory_center_averaged | shared_parent_cache_hit_total_recorded | shared_parent_cache_hit_mean_trajectory_center_averaged | decision_runtime_actual_s_total_recorded | decision_runtime_actual_s_mean_trajectory_center_averaged | decision_runtime_standalone_estimate_s_total_recorded | decision_runtime_standalone_estimate_s_mean_trajectory_center_averaged |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B0 | 20 | 240 | 5760 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 2202.5181463010667 | 9.177158942921112 | 2202.5181463010667 | 9.177158942921112 |
| B1 | 20 | 240 | 5760 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 2296.6412864986924 | 9.569338693744552 | 2296.6412864986924 | 9.569338693744552 |
| B2 | 20 | 240 | 5760 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 5370.878328698687 | 22.378659702911197 | 5370.878328698687 | 22.378659702911197 |
| B8 | 20 | 240 | 5760 | 53280.0 | 222.0 | 2664000.0 | 11100.0 | 0.0 | 0.0 | 0.0 | 0.0 | 34280.914582599944 | 142.83714409416643 | 34280.914582599944 | 142.83714409416643 |
| P7.7 | 20 | 240 | 5760 | 17428.0 | 72.61666666666666 | 871400.0 | 3630.8333333333335 | 0.0 | 0.0 | 0.0 | 0.0 | 15102.04218449854 | 62.92517576874392 | 15102.04218449854 | 62.92517576874392 |

## Original vs Corrected

| method | original_mixed_inventory_mean | corrected_batch20_mean | corrected_minus_original | original_ci_low | original_ci_high | corrected_ci_low | corrected_ci_high | causal_attribution |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| B0 | 0.006049676514516644 | 0.006604798735543227 | 0.0005551222210265832 | 0.00473828067350874 | 0.007475796475300596 | 0.005033902315067533 | 0.008255700132237712 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B1 | 0.002985070205270142 | 0.0033419799126224664 | 0.0003569097073523246 | 0.002286870119930367 | 0.0037692499721896982 | 0.0025065074416425488 | 0.004257924875520683 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B2 | 0.004535350747396975 | 0.004883941472543382 | 0.0003485907251464075 | 0.0036400970088777676 | 0.005557066298132043 | 0.0038601564234488693 | 0.005979564093428911 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B8 | 0.0024859688219723572 | 0.0029126269437559434 | 0.00042665812178358615 | 0.0018613954531421946 | 0.0031797523427849156 | 0.002168176367251312 | 0.003709445781764266 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| P7.7 | 0.002524255871657655 | 0.002940643859084149 | 0.00041638798742649414 | 0.001877003560423972 | 0.003252184798338037 | 0.002189337225937733 | 0.0037421774917814014 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |

| method | scenario | original_mixed_inventory_mean | corrected_batch20_mean | corrected_minus_original | causal_attribution |
| --- | --- | --- | --- | --- | --- |
| B0 | C0 | 0.002615431663070912 | 0.0029677385190249577 | 0.00035230685595404564 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B0 | C1 | 0.0051702075418587614 | 0.005501890808530637 | 0.0003316832666718757 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B0 | C3 | 0.012172532316455736 | 0.013005227748302182 | 0.0008326954318464454 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B0 | C4 | 0.004240534536681166 | 0.0049443378663151325 | 0.0007038033296339662 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B1 | C0 | 0.0020945711266297825 | 0.0024897313197773958 | 0.0003951601931476132 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B1 | C1 | 0.00203655827163957 | 0.002379289382083193 | 0.00034273111044362276 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B1 | C3 | 0.005116946711718296 | 0.0053288546640235124 | 0.00021190795230521635 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B1 | C4 | 0.0026922047110929173 | 0.003170044284605764 | 0.0004778395735128469 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B2 | C0 | 0.0025065062120928623 | 0.002903606050676899 | 0.00039709983858403656 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B2 | C1 | 0.002547743572176832 | 0.002935378827351087 | 0.0003876352551742553 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B2 | C3 | 0.009496790749916616 | 0.009563389771069018 | 6.659902115240153e-05 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B2 | C4 | 0.0035903624554015855 | 0.004133391241076525 | 0.0005430287856749397 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B8 | C0 | 0.0024367662204895072 | 0.0028481570255987918 | 0.00041139080510928456 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B8 | C1 | 0.0023029941268052525 | 0.002676047857352791 | 0.0003730537305475386 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B8 | C3 | 0.0027728007816727263 | 0.0033109508967754664 | 0.0005381501151027401 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| B8 | C4 | 0.0024313141589219415 | 0.0028153519952967246 | 0.00038403783637478307 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| P7.7 | C0 | 0.0024367662204895072 | 0.0028481570255987918 | 0.00041139080510928456 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| P7.7 | C1 | 0.0023029941268052525 | 0.0026689542417039367 | 0.0003659601148986841 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| P7.7 | C3 | 0.002885116373989947 | 0.0034232664890926877 | 0.0005381501151027405 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |
| P7.7 | C4 | 0.002472146765345912 | 0.0028221976799411804 | 0.00035005091459526863 | NOT_IDENTIFIED_FROM_MEAN_CHANGE |

| comparison | original_observed_method_mean_difference | corrected_observed_method_mean_difference | corrected_minus_original_difference | corrected_ci_low | corrected_ci_high | original_paired_inference_scope | new_heldout_is_unseen | causal_attribution |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| P7.7 - B0 | -0.003525420642858989 | -0.0036641548764590783 | -0.0001387342336000891 | -0.004573827822422219 | -0.0028134015487948244 | 239 matched groups; one group mismatch; mixed canonical population | False | NOT_IDENTIFIED_FROM_CONTRAST_CHANGE |
| P7.7 - B1 | -0.00046081433361248696 | -0.0004013360535383174 | 5.947828007416955e-05 | -0.0005435194434220294 | -0.00027324824378676267 | 239 matched groups; one group mismatch; mixed canonical population | False | NOT_IDENTIFIED_FROM_CONTRAST_CHANGE |
| P7.7 - B2 | -0.0020110948757393198 | -0.0019432976134592331 | 6.779726228008662e-05 | -0.0022800258030189167 | -0.001616486006572207 | 239 matched groups; one group mismatch; mixed canonical population | False | NOT_IDENTIFIED_FROM_CONTRAST_CHANGE |
| P7.7 - B8 | 3.828704968529767e-05 | 2.8016915328205657e-05 | -1.0270134357092016e-05 | -1.8594825329880642e-07 | 8.423669423791578e-05 | 239 matched groups; one group mismatch; mixed canonical population | False | NOT_IDENTIFIED_FROM_CONTRAST_CHANGE |

## Scientific Verdict

This is an integrity-correction independent replication after original outcomes were observed. It is not an unseen or newly held-out evaluation. Historical final runtime equivalence is NOT_VERIFIED; the authorized independent runtime uses pandas2.3.3/River0.23.0/psutil7.2.2 and binds other frozen scientific dependencies. Frozen original Torch dropout/global RNG remains part of the original method; exact failed-task RNG evidence supports controlled retry, while universal scheduling-invariant stochastic paths are not asserted. Paired input/initial/deployment integrity does not remove that limitation. No estimator refit, threshold adjustment, model-bank change or population reselection is authorized. Action penalties are not complete measured compute cost; cached-call timers, standalone estimates and search counters remain distinct. Python audited IO/causal guards are evidence of the controlled paths, not a general native-library or operating-system sandbox proof. Section3–4 remain subject to the prior manuscript audit: theoretical C1 policy class is not identical to the one-shot P0/10/20/50 offline margin, nor is that margin identical to the normalized MLP online decision score; required paper-only bridging remains unresolved. H_t=min(4,25-t) and the50-update allowance per candidate must not be described as an overall search budget. The old S3–4 audit's characterization of239/961 as merely execution lineage is superseded by the later single-group forensic audit and actual StageB full-batch/singleton input verification. Scientific integrity PASS certifies the replication evidence; it does not automatically freeze Sections3–4, the whole paper, superiority, deployment validity or publication readiness.
## File Index

- `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\EXECUTION_SUMMARY.md`
- `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\INPUT_PARITY_AUDIT.md`
- `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\EXPERIMENT_INTEGRITY_AUDIT.md`
- `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\CORRECTED_FINAL_STATISTICS.md`
- `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\ORIGINAL_VS_REPLICATION_COMPARISON.md`
- `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\SCIENTIFIC_FREEZE_DECISION.md`

Statistics root: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\statistics_batch20_env_v3`. Full raw outputs remain in `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\raw`; raw hashes, source/config/input/environment and phase/failure proofs are in the new package index. Main must archive the preceding root handoff before replacing it; this generator never writes that root file.


## Dynamic execution provenance

Original successful V3 records were retained. The first 123 trajectories used one worker; additional static full_002 records and the real bridge smoke are included in the retained inventory. The FULL dynamic contract retained 332 trajectories and completed 868 with an outcome-blind resource policy capped at three workers. All original failed or interrupted attempts remain preserved. External observer finished timestamps are observation cutoffs; earlier actor/actual exit evidence remains NOT_VERIFIED where applicable. Actual dynamic coordinator and worker exits were observed by their owning Popen objects. No scheduling-invariant or bitwise stochastic output claim is made. The dynamic certificate is separate from old static phase success.
