# Paper 3 — Integrity Replication Handoff (Active Progress)

**PARTIAL.** Verified snapshot: 2026-10-09 approximately17:48 Asia/Shanghai. Repository `D:\dt-talk\DT_LIFECYCLE_ESCALATION`; workspace `D:\dt-talk`. This is an active progress record, not a final scientific certificate. Previous root handoff bytes are archived beside this file.

## Execution Status

Actual corrected trajectories: **5/1200**. Certified five-method groups: **1/240** (the predeclared minimal group). Saved initial-state certificates: **60/60**. Initial phase completed with exit0 at17:27:23.984950 Asia/Shanghai, including its end integrity checks. Actual five-method shared-start proof remains pending trajectories.

Stage A42/42 actual PASS; Stage B input-only RUN003 actual PASS. Current V3 executor93/93 synthetic PASS (attempt004); current sequence/launcher19/19 synthetic PASS (attempt006). Statistics58/58 and delivery55/55 synthetic PASS. Actual package-only transition probe attempt002 PASS. Actual V3 synthetic Torch/SGD probe PASS with its then-current source binding; current observer changes are separately covered by93tests and actual model loading.

**Actual V3 model-load attempt002 PASS**, started16:42:42, completed16:50:46; launcher exited0 at16:50:48. All11 source checkpoints, A1 and operational baseline estimator loaded. Original2535-byte inventory unchanged. No warm-up, optimizer update, lifecycle or statistics executed in that check. Receipt SHA `d60770097520d3579e76e9eb1dcd17829fda0fcce66bff3d8a91a62e06f62fa4`.

**Actual V3 prepare attempt002 PASS at17:04:38**, after the prior failed attempt was retained. Authoritative replication manifest digest: `7eebe390398395b6ebb1247ba2722b6d5928a65b0c06d039b85eacaa39c359ea`. Initial60 certification now passed. The predeclared five-method minimal phase passed all5 trajectories and its group parity/end checks, exiting0 at17:47:15.681257. The full phase started17:47:15 and continues the remaining1195 tasks; it does not rerun or mix historical trajectories. Scientific worker count1. Sequence attempt003 will gate initial60 → predeclared minimal5 → full1200/240 → statistics without requesting another stage confirmation. Future completion is not asserted here.

## Protocol Integrity

Canonical candidate `P7_7_ORIGINAL_BATCH20_CANDIDATE_V1`; input verification protocol `P7_7_CANONICAL_INPUT_VERIFICATION_V1`. The sole selected RUN003 F1 digest remains `ac82f95f4db3b1f624e5348cc8535d75ee3edc8d589c08e74d4aa6fa93f5e228`. No generator rerun, population reselection or old-trajectory reuse is authorized in this model run.

Environment `P7_7_REPLICATION_MODEL_ENV_V1`; runtime descriptor SHA `7e029514ff3d955f1c6046eb8c339580f6cef7f192f95df7456191c855e9b425`. River0.23.0, pandas2.3.3, psutil7.2.2, Torch2.5.1+cu121 and NumPy2.4.6 remain fixed. Exact versions/install sources/wheel SHA/native compatibility and authorized historical differences are recorded under `verification/paper3_canonical_inputs/model_env_recovery_v1_20261009/`. Historical environment identity and numerical neutrality are not claimed.

Frozen core, original runner/generator, source bank/checkpoints, A1, configuration, seeds, zero gate, adaptation budgets and costs remain unchanged. V3 scientific adapter and F1 reader are byte-identical to V2; worker additions only observe the unchanged import boundary and record its proof. A new observer binds actual import-time defaults from exact threadpoolctl3.6.0 source line48 (SHA `12fb9526b6a74d2e686b7ec148dc165c3587999b14fa86984aa180e10802400b`) and sklearn1.9.0 line60 (SHA `ee90855901358fefed403675a8e71a0976a8d5c980fa88323e86c0cda99a8968`). It sets no variable, rejects all other changes and seals actual writer/module/PID/source/environment identity. Model-load002 directly recorded those two writes. Metadata-only statistics use strict raw-state checks and do not import models.

V2's initial process failed before its first warm-up and produced0certificates; its exact changed-variable map was unsaved, so its specific writer attribution remains INFERRED. V3 model-load001 directly proved the previously omitted threadpool-first import path; that failure is preserved. Prepare001 failed because the new output-root authorization scope record was omitted; the agent created the missing documentation under existing explicit human authorization, preserved the failure and retried prepare002. It changed no science. The independent authorization record SHA is `6bcfb32b5b7964d610104da3fe786b0d0248ced4fa1fb0b7ef85be6b8794f9d8`.

The60 canonical warm-up initial-state references are actually certified. The actual minimal group33000/7311/C0 passed shared initial-state, deployment and all24-stage input equality for B0/B1/B2/B8/P7.7. The other239 groups and complete-run causal access are **pending actual full trajectory gates**. Existing software tests alone do not certify them. Git HEAD remains `436ee9960a32a8e94e571ded3fc800a2fa20f3e4`; the five pre-existing tracked modifications are retained, not replication edits.

## Final Scientific Results

No corrected means, contrasts, confidence intervals, scene results, gate/RI rates or diagnostic statistics exist yet. Historical numbers must not be substituted. Bootstrap is permitted only after actual1200/1200 and240/240 checks. It must use20-center joint resampling,4000draws, seed2904 and observed contrasts from actual center means; all unfavorable/non-significant results must be retained.

## Original vs Corrected

The original1200 records remain unchanged and are not reused. Their239 full-batch-origin trajectories and961 singleton-origin trajectories include one internally unpaired five-method group; this is distinct from239 internally matched groups. The new run uses the single frozen full-batch input instance for all methods. Numerical comparison is pending and any future change cannot be assigned to a unique cause without evidence. The correction follows observation of previous held-out outcomes and is never unseen evaluation.

## Scientific Verdict

Environment recovery, input verification, current synthetic tests, actual model loading and source freeze have passed within their actual scope. Initial60 passed actual terminal and manifest checks. Minimal5 and its first1/240 group passed actual terminal/receipt checks. Full1200/240, full-run runtime causal ledger and new statistics remain unverified. No complete scientific-integrity PASS or manuscript freeze is declared. C1 theory/finite labels and C2 online-score calibration limitations remain independent paper issues.

## File Index

- Independent output: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\`.
- Authoritative source/config/environment/input manifest: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\provenance_manifest.json`.
- Fixed input reference: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\input_reference_manifest.json`.
- Current real model loading receipt: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\stage_c_tests\model_load_compatibility\attempt002\model_load_compatibility_receipt.json`.
- Actual minimal gate: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\stage_c_minimal_gate.json`; 5/5 trajectories and the predeclared five-method group passed, performance_used_for_gate=false.
- Independent initial60 review: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\autonomous_replication_execution_20261009_v3\INITIAL60_INDEPENDENT_SAVED_RECORD_REVIEW.md`, SHA `1e06341e159df964a13c0c726dae9555f1ee93e02d5550e36abfda36316a1408`.
- Initial60 manifest: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\initial_state_manifest.json`;60certificates, actual phase launcher exit0. Five-method actual initial-state parity is explicitly `PENDING_TRAJECTORIES`.
- Current executor proof: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7_integrity_replication_batch20_env_v3\stage_c_tests\attempt004\results.json`, SHA `55c56668ac3c1307fe01589ac61ac3b426d0b2b2bcad86ce2d5dd7295c2f0c8d`.
- Current launch/sequence evidence: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\autonomous_replication_execution_20261009_v3\`; sequence `authorized_sequence_003`, prepare `phase_launches/prepare_002`, initial `phase_launches/initial_001`, minimal `phase_launches/minimal_001`, active full `phase_launches/full_001`.
- New executor: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\replication_executor_batch20_env_v3\`.
- Observer/source changes: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\autonomous_replication_execution_20261009_v3\FINAL_THREADPOOL_IMPORT_REVIEW.md`, SHA `be8d0472a0e7f6d0b65e1658e145ac600fe068e9708537d02ed16a253f7fb139`.
- Prepare recovery record: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\autonomous_replication_execution_20261009_v3\CONTROLLED_PREPARE_RESUME_001.json`, SHA `75557f19ace2c358689a577ad06c64fda9f3607528f0fe2e0e36395fea7f8a2d`.
- Statistics source: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\replication_statistics_batch20_env_v3\`.
- Delivery source: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\replication_delivery_env_v3\`.
- Environment inventory: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\`.
- Original untouched results: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\results\p7_7\`.

The six final V3 reports, real statistics CSV, Bootstrap outputs, completed output manifest and final package are still pending. Prior failed sources/logs/receipts and all original data remain separately indexed and preserved. Final packaging must bind these actual provenance limitations and retain raw CSV paths/hashes without copying all large data.
