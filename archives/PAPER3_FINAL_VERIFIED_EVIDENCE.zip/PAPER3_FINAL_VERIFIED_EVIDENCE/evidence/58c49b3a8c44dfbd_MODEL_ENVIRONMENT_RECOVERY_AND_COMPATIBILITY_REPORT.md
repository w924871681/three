# Paper 3 — Independent Model Environment Recovery and Compatibility

**ENVIRONMENT_READY**. Exact dependency selection was fixed before any replication model result. All installation resolver checks and the complete corrected compatibility attempt are genuinely PASS. This document certifies the dependency/native environment only; checkpoint loading, initialization, trajectories, group fairness and statistics are separate root-agent stages and were not executed by the environment-recovery agent.

Target repository: `D:\dt-talk\DT_LIFECYCLE_ESCALATION`.

## Independent runtime identity

- Environment name: `P7_7_REPLICATION_MODEL_ENV_V1`.
- Prefix: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\P7_7_REPLICATION_MODEL_ENV_V1`.
- Python: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\P7_7_REPLICATION_MODEL_ENV_V1\Scripts\python.exe`, CPython3.11.15.
- Base interpreter/stdlib: `C:\Users\92487\anaconda3\envs\rcf-dti-py311`; the venv shares only the normal CPython base runtime/stdlib, whose precise native source snapshot is bound. It does not inherit or import the old site-packages.
- `pyvenv.cfg`: `include-system-site-packages=false`.
- Controlled model startup: `-I -S -B`, explicitly insert only the new prefix's site-packages. Startup `.pth` files are inventoried and not processed by controlled model startup. No editable project was installed.
- Runtime descriptor: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\MODEL_RUNTIME_SPEC.json`, SHA256 `7e029514ff3d955f1c6046eb8c339580f6cef7f192f95df7456191c855e9b425`.
- Recovery receipt: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\MODEL_ENVIRONMENT_RECOVERY_RECEIPT.json`, SHA256 `5ee17ce2ce055e5ac83e6351baf8d02ea125efbeaa6934837eebef3896242188`.
- New prefix file inventory: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\MODEL_ENVIRONMENT_FILE_INVENTORY.json`, 23716 bound non-bytecode files; environment fingerprint `8ae27799bb18d41c9ca8c6f1a945ec9814409af04d7f4e2da46feddaddc28d4c`.

## Exact scientific dependency choices and differences

| Package | Exact independent runtime version | Provenance |
|---|---|---|
| torch | `2.5.1+cu121` | exact frozen installed distribution copied byte-for-byte with source/destination SHA and RECORD verification |
| torchaudio | `2.5.1+cu121` | exact frozen installed distribution copied byte-for-byte with source/destination SHA and RECORD verification |
| torchvision | `0.20.1+cu121` | exact frozen installed distribution copied byte-for-byte with source/destination SHA and RECORD verification |
| numpy | `2.4.6` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |
| scipy | `1.17.1` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |
| scikit-learn | `1.9.0` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |
| pandas | `2.3.3` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |
| river | `0.23.0` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |
| psutil | `7.2.2` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |
| pytz | `2025.2` | official PyPI metadata + non-yanked compatible wheel, archive SHA verified, offline hash-enforced install |

There are 35 exact `==` pins in the original requirements: 34 remain exact matches and the sole authorized replacement is pandas3.0.5→2.3.3. River0.23.0, psutil7.2.2 and pandas2.x's required pytz2025.2 are separately pinned additions. All other requirements pins are preserved. Original `requirements_frozen.txt`, original Python environments and frozen algorithm/model files are not modified by these recovery scripts. The unrelated editable Git package in the historical requirements was deliberately not installed: project execution uses the target repository's frozen sources, and an editable outside repository is not an authorized dependency source.

River0.23.0's official requirement is `pandas>=2.2.3,<3.0.0`, `numpy>=1.23.0`, `scipy>=1.14.1,<2.0.0`; pandas2.3.3 is a fixed non-yanked stable release with an exact CPython3.11 Windows wheel and satisfies that interval. psutil7.2.2 is the non-yanked stable version returned by official metadata, with cp37-abi3 Windows wheel compatible with CPython3.11; the original code's `virtual_memory/cpu_count` APIs were actually tested. It is not claimed to be the historical psutil version. pytz2025.2 is the exact official fixed release needed to satisfy pandas2.x's timezone dependency. These decisions preceded all new model outcomes and were not selected by loss or significance.

The venv bootstrap installs pip24.0/setuptools79.0.1 from the CPython3.11 ensurepip bundle. These packaging tools differ from the preexisting environment and are separately listed by `requirements_runtime_exact_freeze.txt`; they are not model algorithms. No original package was uninstalled or upgraded.

Historical complete final runtime equivalence is **NOT_VERIFIED**. The independent environment is neither represented as the exact historical runtime nor as an unseen held-out evaluation. Approved pandas compatibility changes can affect parsing or numeric support; they do not authorize changing scientific methods, input values, thresholds or selection rules. The root execution must still certify frozen checkpoint loading, input/initial-state/deployment fairness and causal traces.

## Frozen native copying and precise evidence limits

`FROZEN_NATIVE_PACKAGE_COPY_RECEIPT.json` records 11368 source/destination RECORD rows, including repeated normalized Windows aliases, with byte equality and verification of every populated RECORD digest/size. Torch, torchaudio and torchvision package/source/native bytes are copied into the independent prefix, never borrowed from an external site-packages at runtime. 2286 generated bytecode rows are excluded; original bytecode remains untouched and controlled execution uses `-B`.

The preexisting distributions' original archive download provenance is **NOT_VERIFIED**. Their precise locally frozen installed bytes, native DLLs, metadata and RECORD are fully bound instead. This does not fabricate an archive SHA. Exact copied console launchers remain provenance material and are not invoked: all controlled entry commands use the new venv Python executable. Python base DLLs and native support libraries are recorded; Windows/GPU driver differences remain a historical equivalence limitation.

## Complete actual verification

Pip installation used all 35 verified official wheels with `--require-hashes --no-index --no-cache-dir`, and kept the dependency resolver enabled. Installation exited0. Both real pip-check attempts exited0 with `No broken requirements found.` No declaration conflict was ignored and no `--no-deps` installation was used.

| Check | Actual final result |
|---|---|
| `exact_scientific_versions` | PASS |
| `required_package_imports` | PASS |
| `stage_b_numpy_exact_file_identity` | PASS |
| `numpy_scipy_sklearn_pandas_minimum_compatibility` | PASS |
| `torch_cpu_basic_tensor` | PASS |
| `torch_cuda_basic_tensor` | PASS |
| `river_adwin_native_minimum_compatibility` | PASS |
| `psutil_resource_apis` | PASS |

StageB NumPy identity: all 772 bound source/native files match exactly; no mismatch, no input regenerated. Original StageB environment manifest SHA `24ba5d39f7f950735a79b844efeb118d24992e878ef65667a24ef202292f70e8`. The exact same NumPy/OpenBLAS/native bytes are retained despite the new package installation prefix.

CUDA actual test: Torch `2.5.1+cu121`, CUDA `12.1`, 1 device, `_CudaDeviceProperties(name='NVIDIA GeForce RTX 3060 Laptop GPU', major=8, minor=6, total_memory=6143MB, multi_processor_count=30, uuid=5ce4dcb0-372a-37a7-64e9-ae708d1c204c, L2_cache_size=3MB)`. CPU and CUDA matrix tests passed. River ADWIN received only a 1024-sample synthetic zero→one stream and detected drift at stored indices [543]; no project telemetry, estimator fit, model training or optimization ran here.

The resource test recorded 16828862464 bytes RAM and 209846272 available during that process, plus 20 CPUs. These are resource observations, not model outcomes. The root scheduler may lower worker count under the existing authorization without changing scientific calculations.

Final actual check receipt: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\NATIVE_COMPATIBILITY_TEST_RECEIPT_ATTEMPT002.json`; subprocess execution receipt: `D:\dt-talk\DT_LIFECYCLE_ESCALATION\verification\paper3_canonical_inputs\model_env_recovery_v1_20261009\ENVIRONMENT_CHECKS_EXECUTION_RECEIPT_ATTEMPT002.json`. The first native attempt's eight scientific/package checks already passed but overall failed at a new diagnostic logger accessing unsupported `pmmap_grouped.size`; its overall FAIL receipt and logs remain unmodified. The corrected logger uses the actual namedtuple `_asdict()` API, and the entire suite was rerun, not merely relabeled.

## Ordinary recovery implementation events

1. The metadata downloader initially rejected fonttools because both a cp311 native and a pure Python wheel existed. The independent finalizer selected the exact original cp311 ABI; original failure manifest remains.
2. A new metadata reader initially used Windows default GBK on official UTF-8 JSON. Explicit UTF-8 corrected only the new recovery helper.
3. Frozen torchvision RECORD includes slash and backslash spellings of identical physical paths. The first no-overwrite copy stopped; the explicit recovery compares every existing destination SHA exactly with its frozen source and never writes existing files. `COPY_ATTEMPT_01_FAILURE_RECORD.json` preserves that event.
4. The diagnostic memory-map logger error was corrected only in new verification code; previous source snapshots are in `ordinary_impl_fix_history/` and previous receipt/logs remain intact. Exact pins and computations were unchanged.

No stub, deleted algorithm import, Python3.13 native extension, scientific version substitution, result-conditioned selection or integrity bypass was used.

## Source archives and offline recreation

`requirements_replication_env_v1.lock.txt` binds all new official archive installs. `OFFICIAL_WHEELHOUSE_VERIFIED_V1.json` binds official metadata URL/bytes, wheel URL/size/SHA and fixed versions. `requirements_runtime_exact_freeze.txt` contains the complete installed distribution inventory. Recreate a separate CPython3.11 venv without system site-packages, replay the exact RECORD-verified frozen Torch-package copy, then install the fixed offline wheelhouse with the saved hash lock and enabled resolver. Rerun both pip check and the complete final compatibility script before checkpoint or experimental execution. Never run the copied old console launchers and never edit a finalized environment while an experiment is bound to its fingerprint.

| Fixed archive | SHA256 | Official wheel URL |
|---|---|---|
| Jinja2==3.1.6 | `85ece4451f492d0c13c5dd7c13a64681a86afae63a5f347908daf103ce6d2f67` | https://files.pythonhosted.org/packages/62/a1/3d680cbfd5f4b8f15abc1d571870c5fc3e594bb582bc3b64ea099db13e56/jinja2-3.1.6-py3-none-any.whl |
| MarkupSafe==3.0.3 | `de8a88e63464af587c950061a5e6a67d3632e36df62b986892331d4620a35c01` | https://files.pythonhosted.org/packages/83/8a/4414c03d3f891739326e1783338e48fb49781cc915b2e0ee052aa490d586/markupsafe-3.0.3-cp311-cp311-win_amd64.whl |
| Pygments==2.20.0 | `81a9e26dd42fd28a23a2d169d86d7ac03b46e2f8b59ed4698fb4785f946d0176` | https://files.pythonhosted.org/packages/f4/7e/a72dd26f3b0f4f2bf1dd8923c85f7ceb43172af56d63c7383eb62b332364/pygments-2.20.0-py3-none-any.whl |
| colorama==0.4.6 | `4f1d9991f5acc0ca119f9d443620b77f9d6b33703e51011c16baf57afb285fc6` | https://files.pythonhosted.org/packages/d1/d6/3965ed04c63042e047cb6a3e6ed1a63a35087b6a609aa3a15ed8ac56c221/colorama-0.4.6-py2.py3-none-any.whl |
| contourpy==1.3.3 | `3519428f6be58431c56581f1694ba8e50626f2dd550af225f82fb5f5814d2a42` | https://files.pythonhosted.org/packages/98/4b/9bd370b004b5c9d8045c6c33cf65bae018b27aca550a3f657cdc99acdbd8/contourpy-1.3.3-cp311-cp311-win_amd64.whl |
| cycler==0.12.1 | `85cef7cff222d8644161529808465972e51340599459b8ac3ccbac5a854e0d30` | https://files.pythonhosted.org/packages/e7/05/c19819d5e3d95294a6f5947fb9b9629efb316b96de511b418c53d245aae6/cycler-0.12.1-py3-none-any.whl |
| filelock==3.32.0 | `d396bea984af47333ef05e50eae7eff88c84256de6112aea0ec48a233c064fe3` | https://files.pythonhosted.org/packages/06/79/b4c714bef36bc4ec2beeae1e0c124f0223888cd8c6feb1cdc56038116920/filelock-3.32.0-py3-none-any.whl |
| fonttools==4.63.0 | `063e08bd17bd5a90127a14123de0d6a952dbc847695fd98b63c043d58057f90c` | https://files.pythonhosted.org/packages/08/60/defa5e69641db890a63be281f41345f4c33b157824eaf0b9fad3e08b0dcb/fonttools-4.63.0-cp311-cp311-win_amd64.whl |
| fsspec==2026.6.0 | `02e0b71817df9b2169dc30a16832045764def1191b43dcff5bb85bdee212d2a1` | https://files.pythonhosted.org/packages/e5/22/4222d7ddf3da30f363edaa98e329c2bce6c65497c9cb2810931c8b2c0fbc/fsspec-2026.6.0-py3-none-any.whl |
| iniconfig==2.3.0 | `f631c04d2c48c52b84d0d0549c99ff3859c98df65b3101406327ecc7d53fbf12` | https://files.pythonhosted.org/packages/cb/b1/3846dd7f199d53cb17f49cba7e651e9ce294d8497c8c150530ed11865bb8/iniconfig-2.3.0-py3-none-any.whl |
| joblib==1.5.3 | `5fc3c5039fc5ca8c0276333a188bbd59d6b7ab37fe6632daa76bc7f9ec18e713` | https://files.pythonhosted.org/packages/7b/91/984aca2ec129e2757d1e4e3c81c3fcda9d0f85b74670a094cc443d9ee949/joblib-1.5.3-py3-none-any.whl |
| kiwisolver==1.5.0 | `beb7f344487cdcb9e1efe4b7a29681b74d34c08f0043a327a74da852a6749e7b` | https://files.pythonhosted.org/packages/be/6c/28f17390b62b8f2f520e2915095b3c94d88681ecf0041e75389d9667f202/kiwisolver-1.5.0-cp311-cp311-win_amd64.whl |
| matplotlib==3.11.1 | `7f33a781e12b1e53b278deb2f5373c2e55ec4f10727be3440c0cfb5cda9f944f` | https://files.pythonhosted.org/packages/bc/be/fa26ed085b41298f64a8f9b7592c671bbf1acc8b0df124c1c5de96b859f8/matplotlib-3.11.1-cp311-cp311-win_amd64.whl |
| mpmath==1.3.0 | `a0b2b9fe80bbcd81a6647ff13108738cfb482d481d826cc0e02f5b35e5c88d2c` | https://files.pythonhosted.org/packages/43/e3/7d92a15f894aa0c9c4b49b8ee9ac9850d6e63b03c9c32c0367a13ae62209/mpmath-1.3.0-py3-none-any.whl |
| narwhals==2.24.0 | `42fdedf44e5b2ca7505630d45b4ac3058f38d8485cba9fe1652ca23152df7489` | https://files.pythonhosted.org/packages/7e/85/a5bfaebfd305ac18b57b0854d74e37e586809061a91fda62f0bd50c8518e/narwhals-2.24.0-py3-none-any.whl |
| networkx==3.6.1 | `d47fbf302e7d9cbbb9e2555a0d267983d2aa476bac30e90dfbe5669bd57f3762` | https://files.pythonhosted.org/packages/9e/c9/b2622292ea83fbb4ec318f5b9ab867d0a28ab43c5717bb85b0a5f6b3b0a4/networkx-3.6.1-py3-none-any.whl |
| numpy==2.4.6 | `1e254a00cdf42b1e4d5b3d68d33af63268d41340d8885df2ab6470f2e1500147` | https://files.pythonhosted.org/packages/c5/31/7fc6239c12bce7e931463251cca4426c465e1876ba3cc785402ef4dd8f4e/numpy-2.4.6-cp311-cp311-win_amd64.whl |
| packaging==26.0 | `b36f1fef9334a5588b4166f8bcd26a14e521f2b55e6b9de3aaa80d3ff7a37529` | https://files.pythonhosted.org/packages/b7/b9/c538f279a4e237a006a2c98387d081e9eb060d203d8ed34467cc0f0b9b53/packaging-26.0-py3-none-any.whl |
| pandas==2.3.3 | `f086f6fe114e19d92014a1966f43a3e62285109afe874f067f5abbdcbb10e59c` | https://files.pythonhosted.org/packages/8e/59/712db1d7040520de7a4965df15b774348980e6df45c129b8c64d0dbe74ef/pandas-2.3.3-cp311-cp311-win_amd64.whl |
| pillow==12.3.0 | `8e95e1385e4998ae9694eeaa4730ba5457ff61185b3a55e2e7bea0880aef452a` | https://files.pythonhosted.org/packages/63/c6/4bad1b18d132a50b27e1365e1ab163616f7a5bb56d330f66f9d1d9d4f9d4/pillow-12.3.0-cp311-cp311-win_amd64.whl |
| pluggy==1.6.0 | `e920276dd6813095e9377c0bc5566d94c932c33b27a3e3945d8389c374dd4746` | https://files.pythonhosted.org/packages/54/20/4d324d65cc6d9205fabedc306948156824eb9f0ee1633355a8f7ec5c66bf/pluggy-1.6.0-py3-none-any.whl |
| psutil==7.2.2 | `eb7e81434c8d223ec4a219b5fc1c47d0417b12be7ea866e24fb5ad6e84b3d988` | https://files.pythonhosted.org/packages/b4/90/e2159492b5426be0c1fef7acba807a03511f97c5f86b3caeda6ad92351a7/psutil-7.2.2-cp37-abi3-win_amd64.whl |
| pyparsing==3.3.2 | `850ba148bd908d7e2411587e247a1e4f0327839c40e2e5e6d05a007ecc69911d` | https://files.pythonhosted.org/packages/10/bd/c038d7cc38edc1aa5bf91ab8068b63d4308c66c4c8bb3cbba7dfbc049f9c/pyparsing-3.3.2-py3-none-any.whl |
| pypdf==6.14.2 | `3f07891af76dc002657e04993ab9b4de81de29f9013b9761d0b7968bff12e946` | https://files.pythonhosted.org/packages/49/e6/136aa8993a2ae7214e0b0ef2edaa0d2e08d1d4e4982635b08a835ff31ec8/pypdf-6.14.2-py3-none-any.whl |
| pytest==9.1.1 | `37a86b45efb9a47a61a36449063e8e18d0cab3161329fc099eb21783169c4f0c` | https://files.pythonhosted.org/packages/24/25/1de2678b631f5a49215c6c96fff41ba892b0a34df68d6d80292b1b48aa7f/pytest-9.1.1-py3-none-any.whl |
| python-dateutil==2.9.0.post0 | `a8b2bc7bffae282281c8140a97d3aa9c14da0b136dfe83f850eea9a5f7470427` | https://files.pythonhosted.org/packages/ec/57/56b9bcc3c9c6a792fcbaf139543cee77261f3651ca9da0c93f5c1221264b/python_dateutil-2.9.0.post0-py2.py3-none-any.whl |
| pytz==2025.2 | `5ddf76296dd8c44c26eb8f4b6f35488f3ccbf6fbbd7adee0b7262d43f0ec2f00` | https://files.pythonhosted.org/packages/81/c4/34e93fe5f5429d7570ec1fa436f1986fb1f00c3e0f43a589fe2bbcd22c3f/pytz-2025.2-py2.py3-none-any.whl |
| river==0.23.0 | `c343a9f2052986a0939b2abb21a954780d5580d524cdf1ed4d5d526fc7aa9790` | https://files.pythonhosted.org/packages/bd/cc/dd99f3f36568cf2685950874696ee97f72e5cdd6c23d626672386dc71d95/river-0.23.0-cp311-cp311-win_amd64.whl |
| scikit-learn==1.9.0 | `5dc1818c77575d149e25fce9ef82dd7b7263ae372f03494158668ad632a69759` | https://files.pythonhosted.org/packages/3b/67/be3d369f40d8178ba3bd86635d132e08cb5329b023e4669d9426d84bc007/scikit_learn-1.9.0-cp311-cp311-win_amd64.whl |
| scipy==1.17.1 | `d30e57c72013c2a4fe441c2fcb8e77b14e152ad48b5464858e07e2ad9fbfceff` | https://files.pythonhosted.org/packages/95/da/0d1df507cf574b3f224ccc3d45244c9a1d732c81dcb26b1e8a766ae271a8/scipy-1.17.1-cp311-cp311-win_amd64.whl |
| six==1.17.0 | `4721f391ed90541fddacab5acf947aa0d3dc7d27b2e1e8eda2be8970586c3274` | https://files.pythonhosted.org/packages/b7/ce/149a00dd41f10bc29e5921b496af8b574d8413afcd5e30dfa0ed46c2cc5e/six-1.17.0-py2.py3-none-any.whl |
| sympy==1.13.1 | `db36cdc64bf61b9b24578b6f7bab1ecdd2452cf008f34faa33776680c26d66f8` | https://files.pythonhosted.org/packages/b2/fe/81695a1aa331a842b582453b605175f419fe8540355886031328089d840a/sympy-1.13.1-py3-none-any.whl |
| threadpoolctl==3.6.0 | `43a0b8fd5a2928500110039e43a5eed8480b918967083ea48dc3ab9f13c4a7fb` | https://files.pythonhosted.org/packages/32/d5/f9a850d79b0851d1d4ef6456097579a9005b31fea68726a4ae5f2d82ddd9/threadpoolctl-3.6.0-py3-none-any.whl |
| typing_extensions==4.16.0 | `481caa481374e813c1b176ada14e97f1f67a4539ce9cfeb3f350d78d6370c2e8` | https://files.pythonhosted.org/packages/49/d3/b8441a820a491ddfc024b0b0cf0393375b75ea13866d9c66727e54c2fc80/typing_extensions-4.16.0-py3-none-any.whl |
| tzdata==2026.3 | `dc096730c87af6cab1b171c9d532be840741ff5d459015e7f6947bd7d7e54931` | https://files.pythonhosted.org/packages/e5/6d/b53b99a9f2766d095985947a5782f1702cabb129a34f7a802d7197af832f/tzdata-2026.3-py2.py3-none-any.whl |

## Authorization and scope boundary

The researcher explicitly authorized creating this independent Python3.11 runtime, River0.23.0, compatible pandas2.x, evidence-based psutil selection and controlled ordinary recovery fixes. This recovery does not certify initial model state, five-method parity, 1200 trajectories or center-level bootstrap. No checkpoint or project algorithm was loaded by this recovery agent. The root agent may automatically proceed to those already authorized stages only after its separate frozen SHA and scientific fairness gates pass. Any scientific conflict still stops progression.
